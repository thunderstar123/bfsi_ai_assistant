# 🚀 Quick Start Guide

Get BFSI AI Assistant running in 5 minutes!

## Option 1: Automated Setup (Recommended)

```bash
# Clone repository
git clone https://github.com/yourusername/bfsi-ai-assistant.git
cd bfsi-ai-assistant

# Run setup script
bash setup.sh

# Activate environment
source venv/bin/activate

# Start application
python -m src.main
```

Visit: http://localhost:8000/docs

## Option 2: Docker (Fastest)

```bash
# Clone repository
git clone https://github.com/yourusername/bfsi-ai-assistant.git
cd bfsi-ai-assistant/deployment

# Start with Docker Compose
docker-compose up -d

# Check status
docker-compose ps
```

Visit: http://localhost:8000/docs

## Option 3: Manual Setup

### 1. Install Dependencies
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your settings
```

### 3. Generate Dataset
```bash
python -m src.data_generator
```

### 4. Start Application
```bash
python -m src.main
```

## Testing the API

### Using cURL
```bash
curl -X POST "http://localhost:8000/api/v1/query" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What are the requirements for a personal loan?",
    "user_id": "test_user"
  }'
```

### Using Python
```python
import requests

response = requests.post(
    "http://localhost:8000/api/v1/query",
    json={
        "query": "What are the requirements for a personal loan?",
        "user_id": "test_user"
    }
)

print(response.json())
```

### Using Browser
Visit: http://localhost:8000/docs

Click "Try it out" on any endpoint!

## Common Commands

```bash
# Generate new dataset
python -m src.data_generator

# Train model (optional)
python -m src.model_trainer

# Run tests
pytest tests/ -v

# View logs
tail -f logs/app.log

# Clear cache
curl -X POST http://localhost:8000/api/v1/cache/clear

# Get statistics
curl http://localhost:8000/api/v1/stats
```

## Next Steps

1. **Customize Dataset**: Edit `src/data_generator.py` to add your own samples
2. **Add Knowledge**: Place `.txt` files in `knowledge_base/` directory
3. **Fine-tune Model**: Run `python -m src.model_trainer` with your dataset
4. **Deploy**: See `docs/DEPLOYMENT.md` for production deployment

## Troubleshooting

### Port already in use
```bash
# Change port in .env
API_PORT=8001
```

### Module not found
```bash
# Ensure virtual environment is activated
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements.txt
```

### Out of memory
```bash
# Edit .env to reduce cache size
CACHE_MAX_SIZE=500

# Or use smaller model
MODEL_NAME=microsoft/phi-1_5
```

## System Requirements

**Minimum:**
- Python 3.10+
- 8GB RAM
- 10GB disk space
- CPU-only supported

**Recommended:**
- Python 3.10+
- 16GB RAM
- 50GB disk space
- NVIDIA GPU (optional)

## Support

- Documentation: `docs/` directory
- API Guide: `docs/API_USAGE.md`
- Deployment: `docs/DEPLOYMENT.md`
- Issues: GitHub Issues

## What's Next?

✅ API is running
✅ Dataset is loaded
✅ Cache is enabled

Try these sample queries:
- "What are the requirements for a personal loan?"
- "How do I calculate EMI?"
- "What is term insurance?"
- "How can I check my account balance?"
- "I want to file a complaint"

Enjoy building with BFSI AI Assistant! 🎉
