# Deployment Guide

## Local Development

### Prerequisites
- Python 3.10+
- 8GB RAM minimum (16GB recommended)
- Git

### Setup Steps

1. **Clone Repository**
```bash
git clone https://github.com/yourusername/bfsi-ai-assistant.git
cd bfsi-ai-assistant
```

2. **Run Setup Script**
```bash
bash setup.sh
```

3. **Activate Virtual Environment**
```bash
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate  # Windows
```

4. **Configure Environment**
```bash
# Edit .env file
nano .env
```

5. **Generate Dataset**
```bash
python -m src.data_generator
```

6. **Train Model** (Optional, can use base model)
```bash
python -m src.model_trainer
```

7. **Run Application**
```bash
python -m src.main
```

Visit: http://localhost:8000

## Docker Deployment

### Prerequisites
- Docker 20.10+
- Docker Compose 2.0+

### Quick Start

1. **Clone Repository**
```bash
git clone https://github.com/yourusername/bfsi-ai-assistant.git
cd bfsi-ai-assistant
```

2. **Build and Run**
```bash
cd deployment
docker-compose up -d
```

3. **Check Status**
```bash
docker-compose ps
docker-compose logs -f
```

4. **Stop Services**
```bash
docker-compose down
```

### Configuration

Edit `deployment/docker-compose.yml` to customize:
- Ports
- Environment variables
- Resource limits
- Volumes

## Cloud Deployment

### AWS EC2

1. **Launch EC2 Instance**
- AMI: Ubuntu 22.04 LTS
- Instance Type: t3.large or larger
- Storage: 30GB+ SSD
- Security Group: Open port 8000

2. **Connect to Instance**
```bash
ssh -i your-key.pem ubuntu@your-ec2-ip
```

3. **Install Docker**
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker ubuntu
```

4. **Deploy Application**
```bash
git clone https://github.com/yourusername/bfsi-ai-assistant.git
cd bfsi-ai-assistant/deployment
docker-compose up -d
```

5. **Setup Nginx Reverse Proxy**
```bash
sudo apt install nginx -y
```

Create `/etc/nginx/sites-available/bfsi-assistant`:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/bfsi-assistant /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Google Cloud Platform (GCP)

1. **Create GCP Project**
```bash
gcloud projects create bfsi-assistant
gcloud config set project bfsi-assistant
```

2. **Deploy to Cloud Run**
```bash
# Build and push image
gcloud builds submit --tag gcr.io/bfsi-assistant/api

# Deploy to Cloud Run
gcloud run deploy bfsi-assistant \
  --image gcr.io/bfsi-assistant/api \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 4Gi \
  --cpu 2
```

### Azure

1. **Create Container Instance**
```bash
az group create --name bfsi-rg --location eastus

az container create \
  --resource-group bfsi-rg \
  --name bfsi-assistant \
  --image yourdockerhub/bfsi-assistant:latest \
  --dns-name-label bfsi-assistant \
  --ports 8000 \
  --cpu 2 \
  --memory 4
```

## Kubernetes Deployment

### Create Kubernetes Manifests

**deployment.yaml**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: bfsi-assistant
spec:
  replicas: 3
  selector:
    matchLabels:
      app: bfsi-assistant
  template:
    metadata:
      labels:
        app: bfsi-assistant
    spec:
      containers:
      - name: bfsi-assistant
        image: yourdockerhub/bfsi-assistant:latest
        ports:
        - containerPort: 8000
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: REDIS_HOST
          value: "redis-service"
        resources:
          requests:
            memory: "4Gi"
            cpu: "2"
          limits:
            memory: "8Gi"
            cpu: "4"
```

**service.yaml**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: bfsi-assistant-service
spec:
  type: LoadBalancer
  selector:
    app: bfsi-assistant
  ports:
  - port: 80
    targetPort: 8000
```

**Deploy:**
```bash
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
```

## Production Checklist

### Security
- [ ] Enable HTTPS/TLS
- [ ] Add API authentication (JWT/API keys)
- [ ] Implement rate limiting
- [ ] Set up firewall rules
- [ ] Enable CORS only for trusted domains
- [ ] Use environment variables for secrets
- [ ] Regular security updates

### Performance
- [ ] Enable Redis caching
- [ ] Configure resource limits
- [ ] Set up load balancing
- [ ] Enable HTTP/2
- [ ] Configure CDN for static assets
- [ ] Optimize model loading

### Monitoring
- [ ] Set up logging aggregation (ELK/CloudWatch)
- [ ] Configure alerts
- [ ] Monitor cache hit rates
- [ ] Track response times
- [ ] Set up health checks
- [ ] Monitor resource usage

### Backup
- [ ] Database backups (if applicable)
- [ ] Model version control
- [ ] Configuration backups
- [ ] Log archival strategy

### Scaling
- [ ] Horizontal pod autoscaling (K8s)
- [ ] Auto-scaling groups (AWS)
- [ ] Load balancer configuration
- [ ] Database replication

## Environment Variables

Key environment variables for production:

```bash
# Application
ENVIRONMENT=production
API_WORKERS=4

# Security
ENABLE_SAFETY_CHECK=true
RATE_LIMIT_REQUESTS=1000
RATE_LIMIT_PERIOD=3600

# Cache
ENABLE_CACHE=true
CACHE_TYPE=redis
REDIS_HOST=redis-service
CACHE_TTL=7200

# Logging
LOG_LEVEL=INFO
ENABLE_QUERY_LOGGING=true

# Performance
USE_GPU=true
BATCH_SIZE=8
```

## Troubleshooting

### Application won't start
```bash
# Check logs
docker-compose logs bfsi-assistant

# Check disk space
df -h

# Check memory
free -m
```

### High memory usage
- Reduce CACHE_MAX_SIZE
- Decrease model batch size
- Enable model quantization
- Add swap space

### Slow responses
- Check cache hit rate
- Monitor CPU/GPU usage
- Optimize database queries
- Enable caching
- Scale horizontally

### Model not loading
- Verify model path exists
- Check disk space
- Verify GPU availability
- Check memory limits

## Support

For deployment issues:
- GitHub Issues: https://github.com/yourusername/bfsi-ai-assistant/issues
- Email: support@example.com
- Documentation: https://docs.example.com
