# Project Structure

## Complete Directory Tree

```
bfsi_ai_assistant/
│
├── README.md                       # Project overview and introduction
├── QUICKSTART.md                   # Quick start guide
├── requirements.txt                # Python dependencies
├── setup.sh                        # Automated setup script
├── .env.example                    # Environment variables template
├── .gitignore                      # Git ignore rules
│
├── src/                            # Source code
│   ├── __init__.py
│   ├── config.py                   # Centralized configuration
│   ├── main.py                     # FastAPI application
│   ├── data_generator.py           # Dataset generation
│   ├── model_trainer.py            # Model fine-tuning
│   │
│   ├── core/                       # Core business logic
│   │   ├── __init__.py
│   │   └── assistant.py            # Main BFSI Assistant (3-tier system)
│   │
│   └── utils/                      # Utility modules
│       ├── __init__.py
│       ├── cache.py                # Cache manager (Memory/Redis)
│       └── logger.py               # Logging configuration
│
├── data/                           # Data directory
│   ├── raw/                        # Raw data files
│   │   ├── bfsi_dataset.json      # Training dataset (JSON)
│   │   └── bfsi_dataset.csv       # Training dataset (CSV)
│   └── processed/                  # Processed data
│
├── models/                         # Model storage
│   ├── phi2-bfsi-finetuned/       # Fine-tuned model
│   │   ├── config.json
│   │   ├── pytorch_model.bin
│   │   └── tokenizer/
│   └── faiss_index/               # Vector store index
│       ├── index.faiss
│       └── index.pkl
│
├── knowledge_base/                 # RAG knowledge documents
│   ├── loan_policies.txt
│   ├── insurance_products.txt
│   └── interest_rates.txt
│
├── logs/                           # Application logs
│   ├── app.log                    # Main application log
│   └── queries.log                # Query audit log
│
├── tests/                          # Test suite
│   ├── __init__.py
│   └── test_assistant.py          # Comprehensive tests
│
├── deployment/                     # Deployment configurations
│   ├── Dockerfile                 # Docker image definition
│   └── docker-compose.yml         # Multi-container setup
│
└── docs/                           # Documentation
    ├── ARCHITECTURE.md            # System architecture
    ├── API_USAGE.md               # API documentation
    └── DEPLOYMENT.md              # Deployment guide
```

## File Descriptions

### Root Directory

| File | Description | Lines | Purpose |
|------|-------------|-------|---------|
| `README.md` | Main documentation | ~200 | Project overview, features, setup |
| `QUICKSTART.md` | Quick start guide | ~150 | Get started in 5 minutes |
| `requirements.txt` | Dependencies | ~35 | Python package requirements |
| `setup.sh` | Setup script | ~60 | Automated environment setup |
| `.env.example` | Config template | ~70 | Environment variable reference |
| `.gitignore` | Git ignore | ~80 | Files to exclude from Git |

### Source Code (`src/`)

| File | Description | Lines | Key Classes/Functions |
|------|-------------|-------|----------------------|
| `config.py` | Configuration | ~150 | `Settings`, `get_settings()` |
| `main.py` | FastAPI app | ~250 | `app`, endpoints, middleware |
| `data_generator.py` | Dataset creator | ~400 | `BFSIDatasetGenerator` |
| `model_trainer.py` | Model trainer | ~200 | `ModelTrainer` |

### Core Logic (`src/core/`)

| File | Description | Lines | Key Classes/Functions |
|------|-------------|-------|----------------------|
| `assistant.py` | Main assistant | ~400 | `BFSIAssistant`, tier methods |

### Utilities (`src/utils/`)

| File | Description | Lines | Key Classes/Functions |
|------|-------------|-------|----------------------|
| `cache.py` | Caching system | ~350 | `CacheManager`, `MemoryCache`, `RedisCache` |
| `logger.py` | Logging setup | ~80 | `setup_logger()`, `log_query()` |

### Tests (`tests/`)

| File | Description | Lines | Test Classes |
|------|-------------|-------|-------------|
| `test_assistant.py` | Test suite | ~400 | All component tests |

### Deployment (`deployment/`)

| File | Description | Lines | Purpose |
|------|-------------|-------|---------|
| `Dockerfile` | Container image | ~40 | Docker build |
| `docker-compose.yml` | Orchestration | ~60 | Multi-container setup |

### Documentation (`docs/`)

| File | Description | Pages | Topics |
|------|-------------|-------|--------|
| `ARCHITECTURE.md` | System design | ~500 | Architecture, flow, components |
| `API_USAGE.md` | API guide | ~300 | Endpoints, examples, errors |
| `DEPLOYMENT.md` | Deploy guide | ~400 | Local, Docker, Cloud |

### Knowledge Base (`knowledge_base/`)

| File | Description | Lines | Content |
|------|-------------|-------|---------|
| `loan_policies.txt` | Loan info | ~350 | Policies, rates, EMI |
| `insurance_products.txt` | Insurance | ~350 | Products, claims, benefits |

## Component Count

- **Python Files**: 10
- **Documentation Files**: 6
- **Configuration Files**: 5
- **Test Files**: 1
- **Knowledge Base Files**: 2
- **Deployment Files**: 2

**Total**: 26 files

## Code Statistics

| Component | Files | Lines of Code | Percentage |
|-----------|-------|---------------|------------|
| Core Logic | 1 | ~400 | 20% |
| API Layer | 1 | ~250 | 13% |
| Utilities | 2 | ~430 | 22% |
| Data/Training | 2 | ~600 | 30% |
| Tests | 1 | ~400 | 20% |
| **Total** | **10** | **~2000** | **100%** |

## Key Design Decisions

### 1. Modular Architecture
- Clear separation of concerns
- Independent components
- Easy to test and maintain

### 2. OOP Principles
- Singleton pattern for shared instances
- Factory pattern for cache backends
- Strategy pattern for tier selection
- Template method for query processing

### 3. Configuration Management
- Centralized in `config.py`
- Environment-based settings
- Pydantic validation
- Type safety

### 4. Caching Strategy
- Pluggable backends (Memory/Redis)
- LRU eviction policy
- TTL-based expiration
- Thread-safe operations

### 5. Logging Architecture
- Structured logging with Loguru
- Rotation and compression
- Separate query audit log
- Configurable levels

### 6. Testing Strategy
- Comprehensive unit tests
- Integration tests
- Fixture-based setup
- API endpoint testing

## Dependencies Overview

### Core ML/AI (8 packages)
- `torch` - Deep learning framework
- `transformers` - Model handling
- `sentence-transformers` - Embeddings
- `datasets` - Dataset utilities
- `peft` - LoRA fine-tuning
- `bitsandbytes` - Quantization
- `accelerate` - Training acceleration
- `faiss-cpu` - Vector search

### API Framework (5 packages)
- `fastapi` - Web framework
- `uvicorn` - ASGI server
- `pydantic` - Validation
- `pydantic-settings` - Config
- `python-multipart` - File uploads

### RAG & Embeddings (2 packages)
- `langchain` - RAG framework
- `chromadb` - Vector database

### Caching (1 package)
- `redis` - Distributed cache

### Data & Utilities (5 packages)
- `pandas` - Data manipulation
- `numpy` - Numerical operations
- `scikit-learn` - ML utilities
- `python-dotenv` - Environment
- `loguru` - Logging
- `tqdm` - Progress bars

### Testing (3 packages)
- `pytest` - Test framework
- `pytest-asyncio` - Async tests
- `pytest-cov` - Coverage
- `httpx` - HTTP client

## Size Estimates

| Component | Size |
|-----------|------|
| Source Code | ~50 KB |
| Documentation | ~100 KB |
| Dependencies | ~3 GB (with models) |
| Models (fine-tuned) | ~5 GB |
| FAISS Index | ~100 MB |
| Dataset | ~1 MB |
| Logs (per day) | ~10 MB |

**Total Initial**: ~8.5 GB

## Performance Characteristics

| Metric | Value |
|--------|-------|
| Startup Time | ~30 seconds |
| First Query | ~2 seconds |
| Cached Query | ~50ms |
| Memory Footprint | 4-6 GB |
| Disk Usage | 8-10 GB |

## Extensibility Points

1. **Add New Tier**: Extend `BFSIAssistant` class
2. **Custom Cache Backend**: Implement `CacheBackend` interface
3. **New Endpoints**: Add routes in `main.py`
4. **Additional Checks**: Extend safety filters
5. **Custom Models**: Change `MODEL_NAME` in config
6. **Knowledge Base**: Add `.txt` files to `knowledge_base/`

## Best Practices Implemented

✅ **Code Organization**: Clear module structure
✅ **Configuration**: Environment-based settings
✅ **Error Handling**: Comprehensive exception handling
✅ **Logging**: Structured and rotated logs
✅ **Testing**: Unit and integration tests
✅ **Documentation**: Inline and external docs
✅ **Type Hints**: Static type checking
✅ **Caching**: Multi-level caching
✅ **Security**: Input validation and sanitization
✅ **Monitoring**: Health checks and metrics
✅ **Scalability**: Stateless design
✅ **Maintainability**: Modular and extensible

## Quick Reference

### Common File Paths
```python
# In code
from config import settings

# Dataset
settings.DATASET_PATH

# Models
settings.MODEL_PATH

# Knowledge Base
settings.KNOWLEDGE_BASE_PATH

# Logs
settings.LOG_FILE
```

### Important Classes
```python
# Main assistant
from core.assistant import BFSIAssistant

# Cache manager
from utils.cache import CacheManager

# Configuration
from config import settings
```

### Key Functions
```python
# Process query
assistant.process_query(query, user_id)

# Generate dataset
generator.generate()

# Train model
trainer.train()
```
