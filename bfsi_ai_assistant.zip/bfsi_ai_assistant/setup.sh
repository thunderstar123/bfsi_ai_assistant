#!/bin/bash

# BFSI AI Assistant Setup Script
# This script sets up the complete environment

set -e

echo "🚀 BFSI AI Assistant Setup"
echo "=========================="

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python version
echo -e "\n${YELLOW}Checking Python version...${NC}"
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

# Create virtual environment
echo -e "\n${YELLOW}Creating virtual environment...${NC}"
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
echo -e "\n${YELLOW}Upgrading pip...${NC}"
pip install --upgrade pip

# Install dependencies
echo -e "\n${YELLOW}Installing dependencies...${NC}"
pip install -r requirements.txt

# Copy environment file
if [ ! -f .env ]; then
    echo -e "\n${YELLOW}Creating .env file...${NC}"
    cp .env.example .env
    echo -e "${GREEN}✓ Created .env file${NC}"
    echo "Please edit .env file with your configuration"
else
    echo -e "${GREEN}✓ .env file already exists${NC}"
fi

# Create directories
echo -e "\n${YELLOW}Creating directories...${NC}"
mkdir -p data/raw data/processed models knowledge_base logs

# Generate dataset
echo -e "\n${YELLOW}Generating BFSI dataset...${NC}"
python -m src.data_generator

echo -e "\n${GREEN}✅ Setup complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your configuration"
echo "2. Run: python -m src.model_trainer  (to train model)"
echo "3. Run: python -m src.main  (to start API)"
echo ""
echo "For Docker deployment:"
echo "  cd deployment && docker-compose up -d"
