"""
Model Training Module
Fine-tunes Phi-2 model on BFSI dataset with LoRA
"""

import json
from pathlib import Path
from typing import Dict
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    Trainer,
    TrainingArguments,
    DataCollatorForLanguageModeling
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from loguru import logger
from config import settings


class ModelTrainer:
    """BFSI Model Trainer with LoRA fine-tuning"""
    
    def __init__(self, dataset_path: str = None):
        self.dataset_path = dataset_path or settings.DATASET_PATH
        self.model = None
        self.tokenizer = None
        self.dataset = None
        logger.info("ModelTrainer initialized")
    
    def load_model(self):
        """Load base model with 4-bit quantization"""
        logger.info(f"Loading model: {settings.MODEL_NAME}")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            settings.MODEL_NAME,
            trust_remote_code=True,
            padding_side="right"
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        
        # Load model with quantization
        self.model = AutoModelForCausalLM.from_pretrained(
            settings.MODEL_NAME,
            device_map=settings.DEVICE,
            trust_remote_code=True,
            torch_dtype=torch.float16,
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True
        )
        
        logger.info("✅ Model and tokenizer loaded")
    
    def setup_lora(self):
        """Configure LoRA for parameter-efficient fine-tuning"""
        logger.info("Setting up LoRA...")
        
        self.model = prepare_model_for_kbit_training(self.model)
        
        lora_config = LoraConfig(
            r=16,
            lora_alpha=32,
            target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM"
        )
        
        self.model = get_peft_model(self.model, lora_config)
        
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        all_params = sum(p.numel() for p in self.model.parameters())
        
        logger.info(f"Trainable: {trainable_params:,} ({100 * trainable_params / all_params:.2f}%)")
    
    def format_prompt(self, sample: Dict) -> str:
        """Format sample as instruction-following prompt"""
        return f"""### Instruction:
{sample['instruction']}

### Input:
{sample['input']}

### Response:
{sample['output']}"""
    
    def prepare_dataset(self):
        """Load and tokenize dataset"""
        logger.info(f"Loading dataset from {self.dataset_path}")
        
        with open(self.dataset_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        dataset = Dataset.from_list(data)
        logger.info(f"Loaded {len(dataset)} samples")
        
        def tokenize_function(examples):
            prompts = [self.format_prompt({
                'instruction': inst,
                'input': inp,
                'output': out
            }) for inst, inp, out in zip(
                examples['instruction'],
                examples['input'],
                examples['output']
            )]
            
            tokenized = self.tokenizer(
                prompts,
                truncation=True,
                max_length=settings.MAX_LENGTH,
                padding="max_length"
            )
            
            tokenized["labels"] = tokenized["input_ids"].copy()
            return tokenized
        
        self.dataset = dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=dataset.column_names,
            desc="Tokenizing"
        )
        
        logger.info("✅ Dataset prepared")
    
    def train(self, output_dir: str = None):
        """Execute training"""
        output_dir = output_dir or str(settings.MODELS_DIR / "phi2-bfsi-finetuned")
        
        logger.info("🚀 Starting training...")
        
        # Load model
        self.load_model()
        self.setup_lora()
        self.prepare_dataset()
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=output_dir,
            num_train_epochs=settings.NUM_EPOCHS,
            per_device_train_batch_size=settings.BATCH_SIZE,
            gradient_accumulation_steps=settings.GRADIENT_ACCUMULATION_STEPS,
            learning_rate=settings.LEARNING_RATE,
            fp16=True,
            save_strategy="steps",
            save_steps=settings.SAVE_STEPS,
            logging_steps=10,
            save_total_limit=2,
            report_to="none",
            warmup_steps=50,
            lr_scheduler_type="cosine",
            optim="paged_adamw_8bit"
        )
        
        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False
        )
        
        # Trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=self.dataset,
            data_collator=data_collator
        )
        
        # Train
        trainer.train()
        
        # Save
        logger.info(f"💾 Saving model to {output_dir}")
        trainer.save_model(output_dir)
        self.tokenizer.save_pretrained(output_dir)
        
        logger.info("✅ Training complete!")


if __name__ == "__main__":
    from utils.logger import setup_logger
    setup_logger()
    
    trainer = ModelTrainer()
    trainer.train()
    
    logger.info("\n🎉 Model training finished successfully!")
