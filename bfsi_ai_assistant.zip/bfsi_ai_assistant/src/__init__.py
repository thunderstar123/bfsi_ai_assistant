# BFSI AI Assistant Package
__version__ = "1.0.0"
__author__ = "Your Name"
__description__ = "AI-powered assistant for BFSI call centers"
