"""
BFSI Assistant Core
Main assistant with 3-tier response system, caching, and safety checks
"""

import json
import time
from typing import Dict, Optional, Tuple
import torch
from sentence_transformers import SentenceTransformer, util
from transformers import AutoTokenizer, AutoModelForCausalLM
from langchain.document_loaders import DirectoryLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from loguru import logger
from config import settings
from utils.cache import cache_manager
from utils.logger import log_query


class BFSIAssistant:
    """
    BFSI AI Assistant with 3-tier response system:
    - Tier 1: Dataset matching (fastest, most accurate)
    - Tier 2: Fine-tuned SLM generation
    - Tier 3: RAG-enhanced generation (complex queries)
    """
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize assistant components"""
        if self._initialized:
            return
        
        logger.info("🚀 Initializing BFSI Assistant...")
        
        # Safety keywords
        self.unsafe_keywords = [
            'password', 'pin', 'cvv', 'otp', 'account number',
            'card number', 'ssn', 'social security'
        ]
        
        self.complex_keywords = [
            'why', 'explain', 'how does', 'breakdown', 'calculate',
            'details', 'policy', 'understand', 'compare'
        ]
        
        # Initialize components
        self._load_dataset()
        self._load_model()
        self._load_rag_system()
        
        self._initialized = True
        logger.info("✅ BFSI Assistant ready!")
    
    def _load_dataset(self):
        """Load dataset and create embeddings for Tier 1"""
        logger.info("Loading dataset for Tier 1...")
        
        dataset_path = settings.BASE_DIR / settings.DATASET_PATH
        with open(dataset_path, 'r', encoding='utf-8') as f:
            self.dataset = json.load(f)
        
        # Create embedding model
        self.embedding_model = SentenceTransformer(settings.EMBEDDING_MODEL)
        
        # Create dataset embeddings
        self.dataset_queries = [
            f"{item['instruction']} {item['input']}" 
            for item in self.dataset
        ]
        self.dataset_embeddings = self.embedding_model.encode(
            self.dataset_queries,
            convert_to_tensor=True,
            show_progress_bar=False
        )
        
        logger.info(f"✅ Loaded {len(self.dataset)} dataset samples")
    
    def _load_model(self):
        """Load fine-tuned model for Tier 2"""
        logger.info("Loading fine-tuned model for Tier 2...")
        
        model_path = settings.BASE_DIR / settings.MODEL_PATH
        
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_path,
                trust_remote_code=True
            )
            self.model = AutoModelForCausalLM.from_pretrained(
                model_path,
                device_map=settings.DEVICE,
                trust_remote_code=True,
                torch_dtype=torch.float16
            )
            logger.info("✅ Fine-tuned model loaded")
        except Exception as e:
            logger.warning(f"Fine-tuned model not found: {e}")
            logger.info("Loading base model instead...")
            self.tokenizer = AutoTokenizer.from_pretrained(
                settings.MODEL_NAME,
                trust_remote_code=True
            )
            self.model = AutoModelForCausalLM.from_pretrained(
                settings.MODEL_NAME,
                device_map=settings.DEVICE,
                trust_remote_code=True,
                torch_dtype=torch.float16,
                load_in_4bit=True
            )
            logger.info("✅ Base model loaded")
    
    def _load_rag_system(self):
        """Load RAG system for Tier 3"""
        logger.info("Loading RAG system for Tier 3...")
        
        kb_path = settings.BASE_DIR / settings.KNOWLEDGE_BASE_PATH
        index_path = settings.BASE_DIR / settings.FAISS_INDEX_PATH
        
        # Check if FAISS index exists
        if index_path.exists():
            logger.info("Loading existing FAISS index...")
            embeddings = HuggingFaceEmbeddings(
                model_name=settings.EMBEDDING_MODEL
            )
            self.vectorstore = FAISS.load_local(
                str(index_path),
                embeddings,
                allow_dangerous_deserialization=True
            )
        else:
            logger.info("Creating new FAISS index...")
            self._create_rag_index(kb_path, index_path)
        
        logger.info("✅ RAG system loaded")
    
    def _create_rag_index(self, kb_path, index_path):
        """Create FAISS index from knowledge base"""
        # Load documents
        loader = DirectoryLoader(
            str(kb_path),
            glob="**/*.txt",
            loader_cls=TextLoader
        )
        documents = loader.load()
        
        # Split documents
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.CHUNK_SIZE,
            chunk_overlap=settings.CHUNK_OVERLAP
        )
        chunks = text_splitter.split_documents(documents)
        
        # Create embeddings and vector store
        embeddings = HuggingFaceEmbeddings(
            model_name=settings.EMBEDDING_MODEL
        )
        self.vectorstore = FAISS.from_documents(chunks, embeddings)
        
        # Save index
        index_path.mkdir(parents=True, exist_ok=True)
        self.vectorstore.save_local(str(index_path))
        
        logger.info(f"Created FAISS index with {len(chunks)} chunks")
    
    def _check_safety(self, query: str) -> Tuple[bool, str]:
        """Check if query is safe"""
        query_lower = query.lower()
        for keyword in self.unsafe_keywords:
            if keyword in query_lower:
                return False, "I cannot provide sensitive information like passwords, PINs, or account numbers. Please contact customer care for account-specific queries."
        return True, ""
    
    def _is_complex_query(self, query: str) -> bool:
        """Determine if query needs RAG"""
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in self.complex_keywords)
    
    def _tier1_dataset_match(self, query: str) -> Tuple[bool, str, float]:
        """Tier 1: Check dataset for similar query"""
        query_embedding = self.embedding_model.encode(
            query,
            convert_to_tensor=True,
            show_progress_bar=False
        )
        
        similarities = util.pytorch_cos_sim(
            query_embedding,
            self.dataset_embeddings
        )[0]
        
        best_idx = torch.argmax(similarities).item()
        best_score = similarities[best_idx].item()
        
        if best_score >= settings.SIMILARITY_THRESHOLD:
            response = self.dataset[best_idx]['output']
            return True, response, best_score
        
        return False, "", best_score
    
    def _tier2_model_generation(self, query: str, context: str = "") -> str:
        """Tier 2: Generate using fine-tuned model"""
        prompt = f"""### Instruction:
You are a BFSI customer service assistant. Provide accurate, compliant, and helpful responses.

### Input:
{query}

{f'### Context:{context}' if context else ''}

### Response:"""
        
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=200,
                temperature=0.7,
                top_p=0.9,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        response = response.split("### Response:")[-1].strip()
        
        return response
    
    def _tier3_rag_generation(self, query: str) -> str:
        """Tier 3: Generate with RAG context"""
        docs = self.vectorstore.similarity_search(query, k=settings.RAG_TOP_K)
        context = "\n\n".join([doc.page_content for doc in docs])
        
        response = self._tier2_model_generation(query, context)
        return response
    
    def process_query(self, query: str, user_id: str = "anonymous") -> Dict:
        """Main query processing pipeline with caching"""
        start_time = time.time()
        
        # Check cache first
        cached_response = cache_manager.get(query, user_id)
        if cached_response:
            cached_response['cached'] = True
            cached_response['processing_time'] = time.time() - start_time
            logger.info(f"Cache HIT for query: {query[:50]}")
            return cached_response
        
        # Safety check
        is_safe, safety_msg = self._check_safety(query)
        if not is_safe:
            result = {
                "response": safety_msg,
                "tier": "safety",
                "confidence": 1.0,
                "cached": False,
                "processing_time": time.time() - start_time
            }
            cache_manager.set(query, result, user_id)
            log_query(user_id, query, safety_msg, "safety", result['processing_time'])
            return result
        
        # Tier 1: Dataset matching
        is_match, response, score = self._tier1_dataset_match(query)
        if is_match:
            result = {
                "response": response,
                "tier": "dataset",
                "confidence": float(score),
                "cached": False,
                "processing_time": time.time() - start_time
            }
            cache_manager.set(query, result, user_id, ttl=settings.CACHE_TTL * 2)
            log_query(user_id, query, response, "dataset", result['processing_time'])
            return result
        
        # Tier 3: RAG for complex queries
        if self._is_complex_query(query):
            response = self._tier3_rag_generation(query)
            result = {
                "response": response,
                "tier": "rag",
                "confidence": 0.85,
                "cached": False,
                "processing_time": time.time() - start_time
            }
            cache_manager.set(query, result, user_id)
            log_query(user_id, query, response, "rag", result['processing_time'])
            return result
        
        # Tier 2: Model generation
        response = self._tier2_model_generation(query)
        result = {
            "response": response,
            "tier": "model",
            "confidence": 0.80,
            "cached": False,
            "processing_time": time.time() - start_time
        }
        cache_manager.set(query, result, user_id)
        log_query(user_id, query, response, "model", result['processing_time'])
        return result


# Singleton instance
assistant = BFSIAssistant()
