"""
Configuration Module
Centralized configuration management with validation
"""

from pydantic_settings import BaseSettings
from pydantic import Field, validator
from typing import List, Literal
import os
from pathlib import Path


class Settings(BaseSettings):
    """Application settings with validation"""
    
    # Application
    APP_NAME: str = "BFSI AI Assistant"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: Literal["development", "production", "testing"] = "development"
    
    # Paths
    BASE_DIR: Path = Path(__file__).parent.parent
    DATA_DIR: Path = BASE_DIR / "data"
    MODELS_DIR: Path = BASE_DIR / "models"
    KNOWLEDGE_BASE_DIR: Path = BASE_DIR / "knowledge_base"
    LOGS_DIR: Path = BASE_DIR / "logs"
    
    # Model Configuration
    MODEL_NAME: str = "microsoft/phi-2"
    MODEL_PATH: str = "models/phi2-bfsi-finetuned"
    EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"
    
    # Dataset
    DATASET_PATH: str = "data/raw/bfsi_dataset.json"
    SIMILARITY_THRESHOLD: float = Field(default=0.75, ge=0.0, le=1.0)
    MAX_DATASET_SAMPLES: int = 200
    
    # RAG Configuration
    KNOWLEDGE_BASE_PATH: str = "knowledge_base"
    FAISS_INDEX_PATH: str = "models/faiss_index"
    RAG_TOP_K: int = Field(default=3, ge=1, le=10)
    CHUNK_SIZE: int = Field(default=500, ge=100, le=2000)
    CHUNK_OVERLAP: int = Field(default=50, ge=0, le=500)
    
    # Cache Configuration
    ENABLE_CACHE: bool = True
    CACHE_TYPE: Literal["memory", "redis"] = "memory"
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    CACHE_TTL: int = 3600
    CACHE_MAX_SIZE: int = 1000
    
    # API Configuration
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_WORKERS: int = 1
    API_RELOAD: bool = True
    CORS_ORIGINS: List[str] = ["*"]
    
    # Training Configuration
    BATCH_SIZE: int = 4
    LEARNING_RATE: float = 2e-4
    NUM_EPOCHS: int = 3
    MAX_LENGTH: int = 512
    GRADIENT_ACCUMULATION_STEPS: int = 4
    SAVE_STEPS: int = 50
    
    # Safety Configuration
    ENABLE_SAFETY_CHECK: bool = True
    MAX_QUERY_LENGTH: int = 500
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 3600
    
    # Logging
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    LOG_FILE: str = "logs/app.log"
    ENABLE_QUERY_LOGGING: bool = True
    
    # Performance
    USE_GPU: bool = True
    DEVICE: str = "auto"
    
    @validator("LOGS_DIR", "DATA_DIR", "MODELS_DIR", "KNOWLEDGE_BASE_DIR")
    def create_directories(cls, v):
        """Create directories if they don't exist"""
        v.mkdir(parents=True, exist_ok=True)
        return v
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# Singleton pattern for settings
_settings = None

def get_settings() -> Settings:
    """Get application settings (Singleton)"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


# Export for easy import
settings = get_settings()
