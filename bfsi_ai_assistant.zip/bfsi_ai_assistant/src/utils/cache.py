"""
Cache Manager Module
Intelligent caching with multiple backend support (Memory/Redis)
"""

import hashlib
import json
import time
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from collections import OrderedDict
from loguru import logger
from config import settings


class CacheBackend(ABC):
    """Abstract base class for cache backends"""
    
    @abstractmethod
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Retrieve cached value"""
        pass
    
    @abstractmethod
    def set(self, key: str, value: Dict[str, Any], ttl: int = None):
        """Store value in cache"""
        pass
    
    @abstractmethod
    def delete(self, key: str):
        """Delete cached value"""
        pass
    
    @abstractmethod
    def clear(self):
        """Clear all cache"""
        pass
    
    @abstractmethod
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        pass


class MemoryCache(CacheBackend):
    """In-memory LRU cache implementation"""
    
    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        self.cache: OrderedDict = OrderedDict()
        self.max_size = max_size
        self.default_ttl = ttl
        self.hits = 0
        self.misses = 0
        logger.info(f"MemoryCache initialized: max_size={max_size}, ttl={ttl}s")
    
    def _is_expired(self, entry: Dict[str, Any]) -> bool:
        """Check if cache entry is expired"""
        if entry.get('expires_at') is None:
            return False
        return time.time() > entry['expires_at']
    
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Retrieve from cache with LRU update"""
        if key in self.cache:
            entry = self.cache[key]
            if self._is_expired(entry):
                self.delete(key)
                self.misses += 1
                return None
            
            # Move to end (most recently used)
            self.cache.move_to_end(key)
            self.hits += 1
            logger.debug(f"Cache HIT: {key}")
            return entry['value']
        
        self.misses += 1
        logger.debug(f"Cache MISS: {key}")
        return None
    
    def set(self, key: str, value: Dict[str, Any], ttl: int = None):
        """Store in cache with TTL"""
        if key in self.cache:
            self.cache.move_to_end(key)
        
        # Evict oldest if at capacity
        if len(self.cache) >= self.max_size:
            oldest = next(iter(self.cache))
            self.delete(oldest)
            logger.debug(f"Cache EVICT: {oldest}")
        
        ttl = ttl or self.default_ttl
        expires_at = time.time() + ttl if ttl > 0 else None
        
        self.cache[key] = {
            'value': value,
            'expires_at': expires_at,
            'created_at': time.time()
        }
        logger.debug(f"Cache SET: {key}")
    
    def delete(self, key: str):
        """Remove from cache"""
        if key in self.cache:
            del self.cache[key]
            logger.debug(f"Cache DELETE: {key}")
    
    def clear(self):
        """Clear all cache entries"""
        count = len(self.cache)
        self.cache.clear()
        self.hits = 0
        self.misses = 0
        logger.info(f"Cache CLEARED: {count} entries removed")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.hits + self.misses
        hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0
        
        return {
            'backend': 'memory',
            'size': len(self.cache),
            'max_size': self.max_size,
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': f"{hit_rate:.2f}%",
            'total_requests': total_requests
        }


class RedisCache(CacheBackend):
    """Redis cache implementation"""
    
    def __init__(self, host: str = 'localhost', port: int = 6379, 
                 db: int = 0, ttl: int = 3600):
        try:
            import redis
            self.redis_client = redis.Redis(
                host=host, 
                port=port, 
                db=db,
                decode_responses=True
            )
            self.redis_client.ping()
            self.default_ttl = ttl
            self.hits = 0
            self.misses = 0
            logger.info(f"RedisCache connected: {host}:{port}/{db}")
        except Exception as e:
            logger.error(f"Redis connection failed: {e}. Falling back to MemoryCache.")
            raise
    
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """Retrieve from Redis"""
        try:
            value = self.redis_client.get(key)
            if value:
                self.hits += 1
                logger.debug(f"Redis HIT: {key}")
                return json.loads(value)
            self.misses += 1
            logger.debug(f"Redis MISS: {key}")
            return None
        except Exception as e:
            logger.error(f"Redis GET error: {e}")
            return None
    
    def set(self, key: str, value: Dict[str, Any], ttl: int = None):
        """Store in Redis with TTL"""
        try:
            ttl = ttl or self.default_ttl
            serialized = json.dumps(value)
            self.redis_client.setex(key, ttl, serialized)
            logger.debug(f"Redis SET: {key}")
        except Exception as e:
            logger.error(f"Redis SET error: {e}")
    
    def delete(self, key: str):
        """Delete from Redis"""
        try:
            self.redis_client.delete(key)
            logger.debug(f"Redis DELETE: {key}")
        except Exception as e:
            logger.error(f"Redis DELETE error: {e}")
    
    def clear(self):
        """Clear all Redis cache"""
        try:
            self.redis_client.flushdb()
            self.hits = 0
            self.misses = 0
            logger.info("Redis cache CLEARED")
        except Exception as e:
            logger.error(f"Redis CLEAR error: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get Redis statistics"""
        try:
            info = self.redis_client.info('stats')
            total_requests = self.hits + self.misses
            hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0
            
            return {
                'backend': 'redis',
                'keyspace_hits': info.get('keyspace_hits', 0),
                'keyspace_misses': info.get('keyspace_misses', 0),
                'hits': self.hits,
                'misses': self.misses,
                'hit_rate': f"{hit_rate:.2f}%",
                'total_requests': total_requests
            }
        except Exception as e:
            logger.error(f"Redis STATS error: {e}")
            return {'backend': 'redis', 'error': str(e)}


class CacheManager:
    """Unified cache manager with backend abstraction"""
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize cache backend based on configuration"""
        if self._initialized:
            return
        
        self.enabled = settings.ENABLE_CACHE
        
        if not self.enabled:
            logger.warning("Cache is DISABLED")
            self.backend = None
            self._initialized = True
            return
        
        # Initialize backend
        try:
            if settings.CACHE_TYPE == "redis":
                self.backend = RedisCache(
                    host=settings.REDIS_HOST,
                    port=settings.REDIS_PORT,
                    db=settings.REDIS_DB,
                    ttl=settings.CACHE_TTL
                )
            else:
                self.backend = MemoryCache(
                    max_size=settings.CACHE_MAX_SIZE,
                    ttl=settings.CACHE_TTL
                )
        except Exception as e:
            logger.warning(f"Failed to initialize {settings.CACHE_TYPE} cache: {e}")
            logger.info("Falling back to MemoryCache")
            self.backend = MemoryCache(
                max_size=settings.CACHE_MAX_SIZE,
                ttl=settings.CACHE_TTL
            )
        
        self._initialized = True
        logger.info(f"CacheManager initialized with {type(self.backend).__name__}")
    
    @staticmethod
    def generate_key(query: str, user_id: str = "") -> str:
        """Generate cache key from query"""
        content = f"{query.lower().strip()}:{user_id}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def get(self, query: str, user_id: str = "") -> Optional[Dict[str, Any]]:
        """Get cached response"""
        if not self.enabled or self.backend is None:
            return None
        
        key = self.generate_key(query, user_id)
        return self.backend.get(key)
    
    def set(self, query: str, response: Dict[str, Any], 
            user_id: str = "", ttl: int = None):
        """Cache response"""
        if not self.enabled or self.backend is None:
            return
        
        key = self.generate_key(query, user_id)
        self.backend.set(key, response, ttl)
    
    def clear(self):
        """Clear all cache"""
        if self.backend:
            self.backend.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        if not self.enabled or self.backend is None:
            return {'enabled': False}
        
        stats = self.backend.get_stats()
        stats['enabled'] = True
        return stats


# Singleton instance
cache_manager = CacheManager()
