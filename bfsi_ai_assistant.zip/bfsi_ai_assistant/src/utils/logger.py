"""
Logger Utility Module
Centralized logging with rotation and archival
"""

import sys
from loguru import logger
from pathlib import Path
from config import settings


def setup_logger():
    """Configure application logger with rotation and archival"""
    
    # Remove default handler
    logger.remove()
    
    # Console handler with colors
    logger.add(
        sys.stdout,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
        level=settings.LOG_LEVEL,
        colorize=True
    )
    
    # File handler with rotation and compression
    log_path = settings.LOGS_DIR / settings.LOG_FILE.split('/')[-1]
    logger.add(
        log_path,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        level=settings.LOG_LEVEL,
        rotation="100 MB",  # Rotate when file reaches 100MB
        retention="30 days",  # Keep logs for 30 days
        compression="zip",  # Compress rotated logs
        enqueue=True  # Thread-safe
    )
    
    # Query log file (separate for audit)
    if settings.ENABLE_QUERY_LOGGING:
        query_log_path = settings.LOGS_DIR / "queries.log"
        logger.add(
            query_log_path,
            format="{time:YYYY-MM-DD HH:mm:ss} | {message}",
            level="INFO",
            rotation="50 MB",
            retention="90 days",  # Keep query logs longer for audit
            compression="zip",
            filter=lambda record: "QUERY_LOG" in record["extra"]
        )
    
    logger.info(f"Logger initialized: level={settings.LOG_LEVEL}")
    return logger


# Initialize logger
app_logger = setup_logger()


def log_query(user_id: str, query: str, response: str, 
              tier: str, processing_time: float):
    """Log query for audit trail"""
    if not settings.ENABLE_QUERY_LOGGING:
        return
    
    query_logger = logger.bind(QUERY_LOG=True)
    query_logger.info(
        f"USER={user_id} | QUERY={query[:100]} | TIER={tier} | "
        f"TIME={processing_time:.3f}s | RESPONSE_LEN={len(response)}"
    )
