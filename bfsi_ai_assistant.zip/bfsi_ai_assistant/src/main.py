"""
FastAPI Main Application
RESTful API for BFSI AI Assistant
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Optional
import time
from loguru import logger

from config import settings
from core.assistant import assistant
from utils.cache import cache_manager
from utils.logger import setup_logger

# Setup logger
setup_logger()

# Initialize FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-powered assistant for BFSI call centers with 3-tier response system",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request/Response Models
class QueryRequest(BaseModel):
    """Query request model"""
    query: str = Field(..., min_length=1, max_length=settings.MAX_QUERY_LENGTH,
                      description="User query text")
    user_id: str = Field(default="anonymous", description="User identifier")
    
    class Config:
        json_schema_extra = {
            "example": {
                "query": "What are the requirements for a personal loan?",
                "user_id": "user123"
            }
        }


class QueryResponse(BaseModel):
    """Query response model"""
    response: str = Field(..., description="Assistant response")
    tier: str = Field(..., description="Response tier (dataset/model/rag/safety)")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Response confidence")
    cached: bool = Field(..., description="Whether response was cached")
    processing_time: float = Field(..., description="Processing time in seconds")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    version: str
    timestamp: float


class StatsResponse(BaseModel):
    """Statistics response"""
    cache_stats: dict
    total_queries: int


# Middleware for request logging
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests"""
    start_time = time.time()
    
    # Process request
    response = await call_next(request)
    
    # Log request
    process_time = time.time() - start_time
    logger.info(
        f"{request.method} {request.url.path} - "
        f"Status: {response.status_code} - "
        f"Time: {process_time:.3f}s"
    )
    
    return response


# Exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": str(exc) if settings.ENVIRONMENT == "development" else "An error occurred"
        }
    )


# Routes
@app.get("/", response_model=HealthResponse)
async def root():
    """Root endpoint"""
    return HealthResponse(
        status="running",
        version=settings.APP_VERSION,
        timestamp=time.time()
    )


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        version=settings.APP_VERSION,
        timestamp=time.time()
    )


@app.post("/api/v1/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """
    Process user query and return AI response
    
    Processes query through 3-tier system:
    1. Dataset matching (fastest)
    2. Fine-tuned model generation
    3. RAG-enhanced generation (complex queries)
    """
    try:
        # Validate query length
        if len(request.query) > settings.MAX_QUERY_LENGTH:
            raise HTTPException(
                status_code=400,
                detail=f"Query exceeds maximum length of {settings.MAX_QUERY_LENGTH} characters"
            )
        
        # Process query
        result = assistant.process_query(request.query, request.user_id)
        
        logger.info(
            f"Query processed: tier={result['tier']}, "
            f"cached={result['cached']}, time={result['processing_time']:.3f}s"
        )
        
        return QueryResponse(**result)
        
    except Exception as e:
        logger.error(f"Error processing query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/stats", response_model=StatsResponse)
async def get_stats():
    """Get system statistics"""
    try:
        cache_stats = cache_manager.get_stats()
        
        return StatsResponse(
            cache_stats=cache_stats,
            total_queries=cache_stats.get('total_requests', 0)
        )
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/cache/clear")
async def clear_cache():
    """Clear all cache (admin endpoint)"""
    try:
        cache_manager.clear()
        logger.info("Cache cleared via API")
        return {"status": "success", "message": "Cache cleared"}
    except Exception as e:
        logger.error(f"Error clearing cache: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/info")
async def get_info():
    """Get system information"""
    return {
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "model": settings.MODEL_NAME,
        "cache_enabled": settings.ENABLE_CACHE,
        "cache_type": settings.CACHE_TYPE,
        "features": {
            "tier1": "Dataset matching",
            "tier2": "Fine-tuned SLM",
            "tier3": "RAG system",
            "caching": settings.ENABLE_CACHE,
            "safety_checks": settings.ENABLE_SAFETY_CHECK
        }
    }


# Startup event
@app.on_event("startup")
async def startup_event():
    """Execute on application startup"""
    logger.info(f"🚀 Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"Cache: {settings.CACHE_TYPE} ({'enabled' if settings.ENABLE_CACHE else 'disabled'})")
    logger.info(f"Model: {settings.MODEL_NAME}")
    logger.info("Assistant initialization...")
    # Assistant is already initialized via singleton


# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Execute on application shutdown"""
    logger.info("🛑 Shutting down application")
    logger.info("Clearing cache...")
    cache_manager.clear()


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.API_RELOAD,
        workers=settings.API_WORKERS,
        log_level=settings.LOG_LEVEL.lower()
    )
