"""
Test Suite for BFSI AI Assistant
Comprehensive tests for all components
"""

import pytest
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from config import settings
from utils.cache import CacheManager, MemoryCache
from core.assistant import BFSIAssistant


class TestCacheManager:
    """Test cache functionality"""
    
    def test_memory_cache_set_get(self):
        """Test basic cache operations"""
        cache = MemoryCache(max_size=10, ttl=60)
        
        # Set value
        cache.set("test_key", {"value": "test_response"})
        
        # Get value
        result = cache.get("test_key")
        assert result is not None
        assert result["value"] == "test_response"
    
    def test_memory_cache_expiration(self):
        """Test cache expiration"""
        cache = MemoryCache(max_size=10, ttl=1)
        
        cache.set("expire_key", {"value": "should_expire"}, ttl=1)
        
        # Immediate retrieval should work
        result = cache.get("expire_key")
        assert result is not None
        
        # After TTL, should be None
        import time
        time.sleep(2)
        result = cache.get("expire_key")
        assert result is None
    
    def test_memory_cache_lru_eviction(self):
        """Test LRU eviction policy"""
        cache = MemoryCache(max_size=3, ttl=60)
        
        # Fill cache
        cache.set("key1", {"value": "v1"})
        cache.set("key2", {"value": "v2"})
        cache.set("key3", {"value": "v3"})
        
        # Add one more (should evict key1)
        cache.set("key4", {"value": "v4"})
        
        assert cache.get("key1") is None
        assert cache.get("key4") is not None
    
    def test_cache_manager_singleton(self):
        """Test singleton pattern"""
        cache1 = CacheManager()
        cache2 = CacheManager()
        
        assert cache1 is cache2
    
    def test_cache_key_generation(self):
        """Test cache key generation"""
        key1 = CacheManager.generate_key("test query", "user1")
        key2 = CacheManager.generate_key("test query", "user1")
        key3 = CacheManager.generate_key("test query", "user2")
        
        assert key1 == key2  # Same query and user
        assert key1 != key3  # Different user


class TestBFSIAssistant:
    """Test BFSI Assistant functionality"""
    
    @pytest.fixture
    def assistant(self):
        """Create assistant instance"""
        return BFSIAssistant()
    
    def test_assistant_singleton(self, assistant):
        """Test singleton pattern"""
        assistant2 = BFSIAssistant()
        assert assistant is assistant2
    
    def test_safety_check_unsafe_query(self, assistant):
        """Test safety check for unsafe queries"""
        unsafe_queries = [
            "What is my password?",
            "Tell me the PIN",
            "What's my CVV number?",
            "Show me account numbers"
        ]
        
        for query in unsafe_queries:
            is_safe, msg = assistant._check_safety(query)
            assert not is_safe
            assert "sensitive information" in msg.lower()
    
    def test_safety_check_safe_query(self, assistant):
        """Test safety check for safe queries"""
        safe_queries = [
            "What are loan requirements?",
            "How do I apply for a loan?",
            "What is the interest rate?"
        ]
        
        for query in safe_queries:
            is_safe, msg = assistant._check_safety(query)
            assert is_safe
    
    def test_complex_query_detection(self, assistant):
        """Test complex query detection"""
        complex_queries = [
            "Why is the interest rate higher?",
            "Explain how EMI calculation works",
            "Can you breakdown the loan policy?"
        ]
        
        for query in complex_queries:
            assert assistant._is_complex_query(query)
    
    def test_simple_query_detection(self, assistant):
        """Test simple query detection"""
        simple_queries = [
            "What are loan requirements?",
            "How do I apply?",
            "Check my balance"
        ]
        
        for query in simple_queries:
            assert not assistant._is_complex_query(query)
    
    def test_process_query_safety(self, assistant):
        """Test end-to-end query processing with unsafe query"""
        result = assistant.process_query("What is my PIN?")
        
        assert result['tier'] == 'safety'
        assert result['confidence'] == 1.0
        assert 'sensitive information' in result['response'].lower()
    
    def test_process_query_valid(self, assistant):
        """Test end-to-end query processing with valid query"""
        result = assistant.process_query("What are personal loan requirements?")
        
        assert result['tier'] in ['dataset', 'model', 'rag']
        assert 'response' in result
        assert len(result['response']) > 0
        assert result['confidence'] > 0


class TestDatasetGeneration:
    """Test dataset generation"""
    
    def test_dataset_file_exists(self):
        """Test if dataset file exists"""
        dataset_path = settings.BASE_DIR / settings.DATASET_PATH
        
        # If dataset doesn't exist, generate it
        if not dataset_path.exists():
            from data_generator import BFSIDatasetGenerator
            generator = BFSIDatasetGenerator()
            generator.generate()
            generator.save()
        
        assert dataset_path.exists()
    
    def test_dataset_format(self):
        """Test dataset format"""
        import json
        dataset_path = settings.BASE_DIR / settings.DATASET_PATH
        
        with open(dataset_path, 'r') as f:
            dataset = json.load(f)
        
        assert len(dataset) >= 150
        
        # Check format
        for item in dataset[:5]:
            assert 'instruction' in item
            assert 'input' in item
            assert 'output' in item


class TestAPIEndpoints:
    """Test FastAPI endpoints"""
    
    @pytest.fixture
    def client(self):
        """Create test client"""
        from fastapi.testclient import TestClient
        from main import app
        return TestClient(app)
    
    def test_root_endpoint(self, client):
        """Test root endpoint"""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data['status'] == 'running'
    
    def test_health_endpoint(self, client):
        """Test health endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data['status'] == 'healthy'
    
    def test_query_endpoint(self, client):
        """Test query endpoint"""
        response = client.post(
            "/api/v1/query",
            json={
                "query": "What are personal loan requirements?",
                "user_id": "test_user"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert 'response' in data
        assert 'tier' in data
        assert 'confidence' in data
    
    def test_query_endpoint_invalid(self, client):
        """Test query endpoint with invalid data"""
        response = client.post(
            "/api/v1/query",
            json={
                "query": "",  # Empty query
                "user_id": "test_user"
            }
        )
        
        assert response.status_code == 422  # Validation error
    
    def test_stats_endpoint(self, client):
        """Test stats endpoint"""
        response = client.get("/api/v1/stats")
        assert response.status_code == 200
        data = response.json()
        assert 'cache_stats' in data
    
    def test_info_endpoint(self, client):
        """Test info endpoint"""
        response = client.get("/api/v1/info")
        assert response.status_code == 200
        data = response.json()
        assert 'app_name' in data
        assert 'version' in data
        assert 'features' in data


@pytest.mark.integration
class TestIntegration:
    """Integration tests"""
    
    def test_full_pipeline(self):
        """Test complete pipeline from query to response"""
        assistant = BFSIAssistant()
        
        # Test various query types
        queries = [
            "What are loan requirements?",
            "How is EMI calculated?",
            "I want to file a complaint"
        ]
        
        for query in queries:
            result = assistant.process_query(query)
            assert 'response' in result
            assert 'tier' in result
            assert len(result['response']) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
